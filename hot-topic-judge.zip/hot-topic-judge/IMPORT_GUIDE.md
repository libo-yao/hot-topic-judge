# 🛠️ 如何将 SKILL.md 导入到不同 AI 平台

> SKILL.md 本质上是一份**结构化指令文档**，告诉 AI 在特定场景下该按什么流程思考、输出什么格式。

---

## 一、原理：SKILL.md 是什么

`SKILL.md` 不是可执行代码，而是一份**给 AI 看的"岗位手册"**。

里面规定了：
- 什么时候触发（触发场景）
- 按什么步骤思考（9 步判断框架）
- 输出什么格式（带 emoji 的分块模板）
- 不能做什么（6 条否决线、反面示例）

**不同平台的差别只在于：你把这份"手册"放在哪里让 AI 读到。**

---

## 二、各平台具体用法

### 1. Lovable

**路径**：项目设置 → Customization → Skills

**步骤**：
1. 打开你的 Lovable 项目
2. 点击左下角 **⚙️ 设置**
3. 找到 **Skills** 或 **Knowledge** 标签
4. 点击 **新建 Skill**
5. 把 `SKILL.md` 的内容全部粘贴进去
6. 保存后，在聊天输入框里输入 `/hot-topic-judge` 或描述相关场景即可触发

**特点**：Lovable 会自动解析 YAML frontmatter（`--- name / description ---`），并基于 description 做场景匹配。

---

### 2. Claude Code / Claude Desktop (Anthropic)

**路径**：项目目录下的 `.claude/skills/` 文件夹

**步骤**：
```bash
# 在你的项目目录里
cd /your-project
mkdir -p .claude/skills

# 把 SKILL.md 放进去
cp /path/to/SKILL.md .claude/skills/hot-topic-judge.md

# 或者新建一个文件，把内容粘贴进去
```

**原理**：Claude Code 会自动读取 `.claude/skills/` 目录下的所有 `.md` 文件，在对话开始时加载为上下文知识。

**使用方式**：
- 正常对话即可，Claude 会根据你的输入自动匹配 skill
- 或者明确触发：`/skill hot-topic-judge`

---

### 3. Cursor (AI 代码编辑器)

**路径**：`.cursorrules` 文件 或 Project Rules

**步骤**：
1. 在你的项目根目录创建 `.cursorrules` 文件
2. 把 `SKILL.md` 中"判断框架"和"输出格式"的部分粘贴进去
3. 保存后，Cursor 的 AI 助手会在相关对话中遵循这些规则

**或者使用 Project Rules（Cursor 0.40+）**：
1. 按 `Cmd+Shift+P` → "Add New Rule"
2. 粘贴 SKILL.md 内容
3. 给 rule 命名：`hot-topic-judge`
4. 设置触发条件（如文件路径包含 `social-media` 或对话关键词"热点"）

---

### 4. ChatGPT / GPTs (OpenAI)

**路径**：GPTs 编辑器的 Instructions 区域

**步骤**：
1. 打开 [chat.openai.com/gpts](https://chat.openai.com/gpts)
2. 点击 **Create a GPT**
3. 在 **Instructions** 区域粘贴 SKILL.md 的完整内容
4. 在 **Conversation starters** 里添加示例开场：
   - "耐克要不要蹭这个热点？"
   - "帮我判断一下这个热搜"
5. 保存并发布为 Public / Private GPT

**原理**：GPT 的 Instructions 就是 system prompt，SKILL.md 的内容会作为 AI 的"职业培训手册"全程生效。

---

### 5. 通用方法（任何支持 System Prompt 的平台）

如果你用的平台有 **System Prompt** 或 **Custom Instructions** 功能：

直接把 `SKILL.md` 全文粘贴到 System Prompt 区域即可。

例如：
- **Poe** (poe.com)：创建 Bot → System Prompt
- **Perplexity**：Settings → Custom Instructions
- **国内大模型平台**（通义千问、文心一言等）：如有自定义指令功能，粘贴即可

---

## 三、导入后的效果验证

无论你用哪个平台，导入后可以用这句话测试是否生效：

> **测试输入**："这个热点，耐克蹭合适吗？"（附任意一张热搜截图）

**如果生效了**，AI 会按以下格式回复（而不是随便给建议）：

```
🎯 热点判断 | 耐克 × {热点关键词}

【品牌基线】
标签 运动 / 活力 / 潮流 / 拼搏｜人群 ...

【否决线】
✅ 通过

【分类】
...

【契合度】
X.X/10  （关联X×0.3 · 人群X×0.4 · 调性X×0.3）

【风险】
🟢/🟡/🔴 ...

【时效】
最佳发布窗口剩余 X 小时

【结论】
...
```

**如果没生效**（AI 回复还是散文式建议），说明 skill 没被正确加载，检查：
1. 粘贴是否完整（特别是开头的 YAML frontmatter `--- name / description ---`）
2. 平台是否支持自定义指令
3. 是否需要在对话中显式触发（如 `/skill hot-topic-judge`）

---

## 四、快速对照表

| 平台 | 文件/路径 | 粘贴位置 |
|---|---|---|
| **Lovable** | `.agents/skills/` | Settings → Skills |
| **Claude Code** | `.claude/skills/hot-topic-judge.md` | 自动加载 |
| **Cursor** | `.cursorrules` 或 Project Rules | 项目根目录 / 编辑器设置 |
| **ChatGPT GPTs** | 无（在线配置） | Instructions 区域 |
| **Poe** | 无（在线配置） | Bot System Prompt |
| **通用** | 无 | System Prompt / Custom Instructions |

---

## 五、一个完整的示例

假设你的同事小明也想用这个 skill，他在用 **Claude Code**：

1. 他从你的 GitHub 仓库下载了 `SKILL.md`
2. 他在自己的项目里执行：
   ```bash
   mkdir -p .claude/skills
   cp ~/Downloads/SKILL.md .claude/skills/hot-topic-judge.md
   ```
3. 他打开 Claude Code，输入："耐克要不要蹭这个热点？"（附截图）
4. Claude 自动加载 skill，输出结构化判断结果

就这么简单。

---

> **核心要点**：SKILL.md 不是程序代码，不需要"运行"，只需要让 AI 在对话前"读到"它，AI 就会按里面的规则工作。
